﻿using ArenaGameEngine;

namespace ArenaGameConsole
{
    class ConsoleGameEventListener : GameEventListener
    {
        public override void GameRound(Hero attacker, Hero defender, int attack)
        {
            string message = $"{attacker.Name} attacked {defender.Name} for {attack} points";
            if (defender.IsAlive)
            {
                message = message + $" but {defender.Name} survived.";
            }
            else
            {
                message = message + $" and {defender.Name} died.";
            }
            Console.WriteLine(message);
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Knight knight = new Knight("Sir John");
            Rogue rogue = new Rogue("Slim Shady");
            Mage mage = new Mage("Gandalf");
            Joker joker = new Joker("Jester");

            // Добавяне на вашите герои към масива
            Hero[] heroes = new Hero[] { knight, rogue, mage, joker };

            Random random = new Random();

            // Произволно избиране на двама героя за битка
            Hero hero1 = heroes[random.Next(heroes.Length)];
            Hero hero2 = heroes[random.Next(heroes.Length)];

            while (hero1 == hero2) // Проверка за избор на различни герои
            {
                hero2 = heroes[random.Next(heroes.Length)];
            }

            Arena arena = new Arena(hero1, hero2);
            arena.EventListener = new ConsoleGameEventListener();

            Console.WriteLine($"Battle between {hero1.Name} and {hero2.Name} begins.");
            Hero winner = arena.Battle();
            Console.WriteLine($"Battle ended. Winner is: {winner.Name}");

            Console.ReadLine();
        }
    }
}



